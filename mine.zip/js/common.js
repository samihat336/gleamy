
function rotnoMota(){
	document.location.href="./remarks.html";
}

function hello(){
	document.location.href="./signup.html";
}
